package com.daa.citasapp_devamain.model;

import java.util.UUID;

public class Doctor {
    UUID id_Doctor;
    String nombre;
    String email;
    String telefono;

    public Doctor(UUID id, String nombre, String email, String tel) {
        this.id_Doctor = id;
        this.nombre = nombre;
        this.email = email;
        this.telefono = tel;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTel() {
        return telefono;
    }

    public void setTel(String tel) {
        this.telefono = tel;
    }
}
